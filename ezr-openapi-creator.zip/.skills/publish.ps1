# ==============================
#  支持子目录 + 多层文件 + 无死循环
#  你的场景 100% 可用
# ==============================

$outputZip = "ezr-openapi-creator@v1.0.2.zip"
$buildDir = "_build_skills"

# 清理旧文件
if (Test-Path $buildDir) { Remove-Item $buildDir -Recurse -Force }
if (Test-Path $outputZip) { Remove-Item $outputZip -Force }

# 创建标准结构：.skills
$target = Join-Path $buildDir ".skills"
New-Item -ItemType Directory -Path $target -Force | Out-Null

# 复制当前目录所有内容（排除临时文件）
Get-ChildItem -Path . | Where-Object {
    $_.Name -ne $buildDir -and
    $_.Name -ne $outputZip -and
    $_.Name -notmatch "^_|temp|build|\.git|node_modules"
} | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $target -Recurse -Force
}

# 打包（压缩包根目录直接就是 .skills，完美支持 npx）
Set-Location $buildDir
Compress-Archive -Path ".skills" -DestinationPath "../$outputZip" -Force
Set-Location ..

# 清理临时目录
Remove-Item $buildDir -Recurse -Force

Write-Host ""
Write-Host "✅ 打包成功！文件：$outputZip"
Write-Host "👉 安装命令：npx skills add ./$outputZip"
Write-Host ""